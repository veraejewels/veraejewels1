import { BrowserRouter as Router, Routes, Route, Link, useParams } from "react-router-dom";
import { useState } from "react";

function NavigationBar() {
  return (
    <nav className="flex items-center justify-between px-8 py-4 shadow-sm bg-white sticky top-0 z-50">
      <Link to="/" className="text-xl font-bold">Varae Jewels</Link>
      <div className="space-x-4 text-sm">
        <Link to="/shop" className="hover:underline">Shop</Link>
        <Link to="/cart" className="hover:underline">Cart</Link>
        <Link to="/contact" className="hover:underline">Contact</Link>
      </div>
    </nav>
  );
}

function HomePage() {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      <section className="px-8 py-20 text-center bg-gray-50">
        <h1 className="text-4xl md:text-6xl font-bold tracking-wide mb-4">Varae Jewels</h1>
        <p className="text-lg md:text-xl text-gray-600 mb-8">Reflecting Authenticity and Purity</p>
        <Link to="/shop">
          <button className="px-6 py-3 bg-black text-white rounded-2xl shadow-md hover:bg-gray-800 transition">Explore Collection</button>
        </Link>
      </section>

      <section className="px-8 py-16 max-w-7xl mx-auto">
        <h2 className="text-2xl font-semibold mb-8 text-center">Featured Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[1, 2, 3].map((item) => (
            <Link to={`/product/${item}`} key={item}>
              <div className="border p-4 rounded-2xl shadow-sm hover:shadow-lg transition">
                <div className="aspect-square bg-gray-200 rounded-xl mb-4"></div>
                <h3 className="text-lg font-medium">Elegant Diamond Ring</h3>
                <p className="text-gray-500">₹49,999</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="px-8 py-16 bg-gray-100 text-center">
        <h2 className="text-2xl font-semibold mb-4">About Varae Jewels</h2>
        <p className="max-w-2xl mx-auto text-gray-600">
          At Varae Jewels, each piece is designed with elegance, precision, and meaning. We believe in reflecting authenticity and purity through timeless craftsmanship.
        </p>
      </section>

      <section className="px-8 py-16 text-center">
        <h2 className="text-2xl font-semibold mb-4">Get in Touch</h2>
        <p className="text-gray-600 mb-6">Reach us at: contact@varaejewels.com</p>
        <button className="px-6 py-3 border rounded-2xl hover:bg-gray-50">Contact Us</button>
      </section>

      <footer className="px-8 py-8 text-center text-sm text-gray-500 bg-gray-50">
        © {new Date().getFullYear()} Varae Jewels. All rights reserved.
      </footer>
    </div>
  );
}

function ShopPage() {
  return (
    <div className="p-8 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Shop</h1>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[1, 2, 3, 4, 5, 6].map((item) => (
          <Link to={`/product/${item}`} key={item}>
            <div className="border p-4 rounded-xl hover:shadow-md transition">
              <div className="aspect-square bg-gray-200 rounded-lg mb-2"></div>
              <h3 className="font-medium">Product #{item}</h3>
              <p className="text-sm text-gray-500">₹49,999</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

function ProductPage({ id }) {
  return (
    <div className="p-8 max-w-3xl mx-auto">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="aspect-square bg-gray-200 rounded-lg"></div>
        <div>
          <h1 className="text-2xl font-semibold mb-2">Elegant Diamond Ring #{id}</h1>
          <p className="text-xl text-gray-700 mb-4">₹49,999</p>
          <p className="text-gray-600 mb-6">An exquisite piece designed to reflect purity and timeless beauty.</p>
          <button className="px-6 py-3 bg-black text-white rounded-xl hover:bg-gray-800 transition">Add to Cart</button>
        </div>
      </div>
    </div>
  );
}

function CartPage() {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Your Cart</h1>
      <p className="text-gray-500">Your cart is currently empty.</p>
    </div>
  );
}

function CheckoutPage() {
  const [form, setForm] = useState({ name: "", email: "", address: "" });
  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Order placed successfully!");
  };
  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Checkout</h1>
      <form className="space-y-4" onSubmit={handleSubmit}>
        <input name="name" value={form.name} onChange={handleChange} placeholder="Full Name" className="w-full border p-3 rounded" required />
        <input name="email" value={form.email} onChange={handleChange} placeholder="Email" className="w-full border p-3 rounded" required />
        <textarea name="address" value={form.address} onChange={handleChange} placeholder="Shipping Address" className="w-full border p-3 rounded" required />
        <button type="submit" className="px-6 py-3 bg-black text-white rounded-xl hover:bg-gray-800 transition">Place Order</button>
      </form>
    </div>
  );
}

function ContactPage() {
  return (
    <div className="p-8 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Contact Us</h1>
      <p className="text-gray-600 mb-4">Reach out to us at <a href="mailto:contact@varaejewels.com" className="underline">contact@varaejewels.com</a></p>
      <form className="space-y-4">
        <input type="text" placeholder="Your Name" className="w-full border p-3 rounded" />
        <input type="email" placeholder="Your Email" className="w-full border p-3 rounded" />
        <textarea placeholder="Your Message" className="w-full border p-3 rounded"></textarea>
        <button className="px-6 py-3 bg-black text-white rounded-xl hover:bg-gray-800 transition">Send Message</button>
      </form>
    </div>
  );
}

function ProductRouteWrapper() {
  const { id } = useParams();
  return <ProductPage id={id} />;
}

export default function App() {
  return (
    <Router>
      <NavigationBar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/shop" element={<ShopPage />} />
        <Route path="/product/:id" element={<ProductRouteWrapper />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route path="/contact" element={<ContactPage />} />
      </Routes>
    </Router>
  );
}
