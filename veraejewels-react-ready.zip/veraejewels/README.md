# Varae Jewels
Luxury e-commerce website built with React and Tailwind CSS. Deploy-ready with Vercel.