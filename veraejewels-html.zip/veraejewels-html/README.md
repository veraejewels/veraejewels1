# Varae Jewels
Static luxury e-commerce website using HTML and Tailwind CSS.

## Deploy
Upload this folder to GitHub and deploy via Vercel.